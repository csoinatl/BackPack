package Project2;


import java.io.File;
import java.net.URL;

import javax.xml.parsers.FactoryConfigurationError;

//mport org.apache.log4j.PropertyConfigurator;
//import org.apache.log4j.helpers.Loader;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 * log4j configuration/adapter
 * 
 * @author stittlem
 *
 */
public class Log4JAdaptor {
	
	/**
	 *  default filename for log coniguration
	 */
	public static final String DEFAULT_CONFIG_FILE = "/log4j.xml";
	
	/**
	 * dedicated logger for performance logging via the DebugTimer class
	 */
	private static Logger debugTimerLogger = null;
	
	private static long lastModified = 0;
	private static String lastConfFile = "";
	
	
	/**
	 * access to custom defined loggers
	 * @param loggerName
	 * @return returns a custom logger
	 */
	static public Logger getLogger(String loggerName) {
		return Logger.getLogger(loggerName);
	}
	
	/**
	 * @return the default logger
	 */
	static Logger getDefaultLogger() {
		return getDebugTimerLogger();
	}
	
	/**
	 * 
	 */
	public static void configure() {
		configure(DEFAULT_CONFIG_FILE);
	}
	
	public static void configure(String configFile) {
		URL url = Log4JAdaptor.class.getResource(configFile);
		
		System.out.println("Log4JAdaptor.configure: path to configuration file:" + url.getPath());
		
		File file = new File(url.getPath());

		try {
			if (lastModified != file.lastModified() || configFile.compareTo(lastConfFile) != 0) {
				lastModified = file.lastModified();
				lastConfFile = configFile;
				DOMConfigurator.configure(url);
				debugTimerLogger = Logger.getLogger("DebugTimer");
			}
		}
		catch(FactoryConfigurationError fce) {
			System.out.println("Error configuring log4j:" + fce.getMessage());
		}
	}

	
	// static initializer
	static {
		// setup logging with default config file
		configure();
	}

	/**
	 * @return the debugTimerLogger
	 */
	public static Logger getDebugTimerLogger() {
		return debugTimerLogger;
	}

	/**
	 * @return the lastModified
	 */
	public static long getLastModified() {
		return lastModified;
	}

}