package Project2;

public interface Constant {
    public static final String DUBUG_TIME = "Debug Timer";
    public static final String LOG_ENTERING = "---Entering---";
    public static final String LOG_EXITING = "---Exit---";
    public static final String LOG_ELEMENT_SEPARATOR = ":|:";
}
