package Project2;

import org.apache.log4j.Logger;

public class DebugTimer {
	private String className;
	private String methodName;
	private long start;
	private long stop = -1;
	
	// grab the dedicated performance logger
	static Logger logger = Log4JAdaptor.getDebugTimerLogger();
	
	public DebugTimer(String className, String methodName) {
		this.className = className;
		this.methodName = methodName;
		start = System.currentTimeMillis();
		stop = -1;
	}
	
	public String toString() {
		stop = System.currentTimeMillis();
		return "elapsed:" + (stop - start);
	}
	
	public void logDebug() {
		
		if ( logger != null)
			logger.debug(String.format("%s%s%s%s%s", className, Constant.LOG_ELEMENT_SEPARATOR, methodName, Constant.LOG_ELEMENT_SEPARATOR, this.toString() ) );
	}

	public long getStart() {
		return start;
	}

	public long getStop() {
		if ( stop == -1)
			stop = System.currentTimeMillis();
		return stop;
	}
	
	public long getElapsed() {
		return getStop() - getStart();
	}
}